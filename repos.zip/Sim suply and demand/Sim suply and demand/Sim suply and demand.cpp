#include <iostream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <fstream>
#include <memory>
#include <algorithm>
#include <sstream>
#include <typeinfo>

using namespace std;

enum TransactionResult {
    SUCCESSFUL,
    FAILED
};

class Participant {
public:
    int expectedPrice;

    Participant(int expectedPrice) : expectedPrice(expectedPrice) {}

    virtual bool isSatisfied(int price) const = 0;
    virtual void adjustExpectation(bool transactionOccurred) = 0;
    virtual ~Participant() = default;
};

class Buyer : public Participant {
public:
    Buyer(int price) : Participant(price) {}

    bool isSatisfied(int price) const override {
        return price <= expectedPrice;
    }

    void adjustExpectation(bool transactionOccurred) override {
        if (transactionOccurred) {
            expectedPrice = max(expectedPrice - rand() % 5, 0);
        }
        else {
            expectedPrice += rand() % 5;
        }
    }
};

class Seller : public Participant {
public:
    Seller(int price) : Participant(price) {}

    bool isSatisfied(int price) const override {
        return price >= expectedPrice;
    }

    void adjustExpectation(bool transactionOccurred) override {
        if (transactionOccurred) {
            expectedPrice += rand() % 5;
        }
        else {
            expectedPrice = max(expectedPrice - rand() % 5, 0);
        }
    }
};

class Market {
private:
    vector<unique_ptr<Participant>> participants;

public:
    void addParticipant(unique_ptr<Participant> participant) {
        participants.push_back(move(participant));
    }

    const vector<unique_ptr<Participant>>& getParticipants() const {
        return participants;
    }

    void initializeMarketFromString(const string& marketData) {
        int num1;
        int num2;
        
        stringstream ss(marketData);
        int numBuyers, numSellers;
        char comma; // to skip commas in the string

        ss >> numBuyers >> comma >> numSellers >> comma >> num1 >> comma >> num2;

        vector<int> buyerPrices(numBuyers);
        vector<int> sellerPrices(numSellers);
        int variationRange = 5; // Define the range of variation

        for (int i = 0; i < numBuyers; ++i) {
            int variedPrice = getRandomPrice(num1, variationRange);
            addParticipant(make_unique<Buyer>(variedPrice));
        }

        for (int i = 0; i < numSellers; ++i) {
            int variedPrice = getRandomPrice(num2, variationRange);
            addParticipant(make_unique<Seller>(variedPrice));
        }
    }

    

    TransactionResult makeTransaction(Participant& buyer, Participant& seller) {
        if (buyer.isSatisfied(seller.expectedPrice) && seller.isSatisfied(buyer.expectedPrice)) {
            int transactionPrice = (buyer.expectedPrice + seller.expectedPrice) / 2;
            cout << "Transaction at price: $" << transactionPrice << endl;
            buyer.adjustExpectation(true);
            seller.adjustExpectation(true);
            return TransactionResult::SUCCESSFUL;
        }

        return TransactionResult::FAILED;
    }

    void simulateDay() {
        for (auto& participant : participants) {
            participant->adjustExpectation(false);
        }

        int transactions = 0;

        for (size_t i = 0; i < participants.size(); ++i) {
            for (size_t j = i + 1; j < participants.size(); ++j) {
                if (makeTransaction(*participants[i], *participants[j]) == TransactionResult::SUCCESSFUL) {
                    transactions++;
                }
            }
        }

        cout << transactions << " transactions occurred today." << endl;
    }

    int getRandomPrice(int basePrice, int variationRange) {
        return basePrice + (rand() % (variationRange * 2 + 1)) - variationRange;
    }


    friend ostream& operator<<(ostream& os, const Market& market);
};

ostream& operator<<(ostream& os, const Market& market) {
    os << "Market Participants:" << endl;
    for (const auto& participant : market.participants) {
        os << typeid(*participant).name() << " - Expected Price: $" << participant->expectedPrice << endl;
    }
    return os;
}

class MarketFileHandler {
public:
    void saveMarketToFile(const Market& market, const string& filename) {
        ofstream file(filename);
        if (file.is_open()) {
            for (const auto& participant : market.getParticipants()) {
                file << typeid(*participant).name() << " " << participant->expectedPrice << endl;
            }
        }
        else {
            throw runtime_error("Unable to open the file for writing.");
        }
    }

    Market loadMarketFromFile(const string& filename) {
        Market market;
        ifstream file(filename);
        if (file.is_open()) {
            string participantType;
            int price;
            while (file >> participantType >> price) {
                cout << "Loaded: " << participantType << " - Price: $" << price << endl;
                if (participantType == "class Buyer") {
                    market.addParticipant(make_unique<Buyer>(price));
                }
                else if (participantType == "class Seller") {
                    market.addParticipant(make_unique<Seller>(price));
                }
            }
        }
        else {
            throw runtime_error("Unable to open the file for reading.");
        }
        return market;
    }
};

void displayMenu() {
    cout << "1. Simulate Day\n"
        << "2. Print Market Details\n"
        << "3. Save Market to File\n"
        << "4. Exit\n";
}

int main() {
    srand(static_cast<unsigned>(time(0)));

    Market market;
    MarketFileHandler fileHandler;

    string line;
    ifstream inputFile("C:\\Users\\hp\\source\\repos\\VisualSim\\VisualSim\\bin\\Debug\\net6.0-windows\\inputData.txt");
    if (inputFile.is_open()) {
        getline(inputFile, line);
        inputFile.close();
    }
    else {
        cerr << "Unable to open file";
        return 1;
    }

    market.initializeMarketFromString(line);

    int choice = 1;

    do {
        displayMenu();
        cout << "Enter your choice: ";
        cin >> choice;
        cin.clear();
        switch (choice) {
        case 1:
            cout << "Simulating Day..." << endl;
            market.simulateDay();
            break;
        case 2:
            cout << market; // Using overloaded << operator to print market details
            break;
        case 3:
            cout << "Saving Market to file..." << endl;
            fileHandler.saveMarketToFile(market, "C:\\Users\\hp\\source\\repos\\Sim suply and demand\\Sim suply and demand\\market.txt");
            break;
        case 4:
            cout << "Exiting..." << endl;
            break;
        default:
            cout << "Invalid choice. Please enter a valid option." << choice << endl;
        }

    } while (choice != 4);

    return 0;
}

