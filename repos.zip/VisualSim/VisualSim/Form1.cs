using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VisualSim
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            lblBuyersNum.Text = trbBuyer.Value.ToString();
            lblSellersNum.Text = trbSeller.Value.ToString();
            lblMoneyBuyers.Text = trbMoneyBuyers.Value.ToString();
            lblMoneySellers.Text = trbMoneySellers.Value.ToString();
        }

        private void trbBuyer_Scroll(object sender, EventArgs e)
        {
            lblBuyersNum.Text = trbBuyer.Value.ToString();
        }

        private void trbSeller_Scroll(object sender, EventArgs e)
        {
            lblSellersNum.Text = trbSeller.Value.ToString();
        }

        private void trbMoneyBuyers_Scroll(object sender, EventArgs e)
        {
            lblMoneyBuyers.Text = trbMoneyBuyers.Value.ToString();
        }

        private void trbMoneySellers_Scroll(object sender, EventArgs e)
        {
            lblMoneySellers.Text = trbMoneySellers.Value.ToString();
        }

        private void btnDone_Click(object sender, EventArgs e)
        {
            var data = new
            {
                buyers = lblBuyersNum.Text,
                sellers = lblSellersNum.Text,
                buyersMoney = lblMoneyBuyers.Text,
                sellersMoney = lblMoneySellers.Text
            };

            string dataString = $"{data.buyers},{data.sellers},{data.buyersMoney},{data.sellersMoney}";
            string cppExecutablePath = "C:\\Users\\hp\\source\\repos\\Sim suply and demand\\x64\\Debug\\Sim suply and demand.exe";

            File.WriteAllText("inputData.txt", dataString);

            ProcessStartInfo startInfo = new ProcessStartInfo
            {
                FileName = cppExecutablePath,
                UseShellExecute = false
            };

            var result = MessageBox.Show("Do you want to continue?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                using (Process process = new Process { StartInfo = startInfo })
                {
                    process.Start();
                    process.WaitForExit();
                }
                new frmOutput().Show();
            }
            else
            {
                Console.WriteLine("User clicked No.");
            }
        }
    }
}