﻿namespace VisualSim
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            trbBuyer = new TrackBar();
            trbSeller = new TrackBar();
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            lblBuyersNum = new Label();
            lblSellersNum = new Label();
            trbMoneySellers = new TrackBar();
            trbMoneyBuyers = new TrackBar();
            label1 = new Label();
            lblMoneySellers = new Label();
            lblMoneyBuyers = new Label();
            label4 = new Label();
            btnDone = new Button();
            ((System.ComponentModel.ISupportInitialize)trbBuyer).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trbSeller).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trbMoneySellers).BeginInit();
            ((System.ComponentModel.ISupportInitialize)trbMoneyBuyers).BeginInit();
            SuspendLayout();
            // 
            // trbBuyer
            // 
            trbBuyer.BackColor = SystemColors.Control;
            trbBuyer.Location = new Point(71, 252);
            trbBuyer.Maximum = 12;
            trbBuyer.Minimum = 1;
            trbBuyer.Name = "trbBuyer";
            trbBuyer.Orientation = Orientation.Vertical;
            trbBuyer.RightToLeft = RightToLeft.No;
            trbBuyer.Size = new Size(45, 186);
            trbBuyer.TabIndex = 0;
            trbBuyer.TickFrequency = 0;
            trbBuyer.TickStyle = TickStyle.Both;
            trbBuyer.Value = 1;
            trbBuyer.Scroll += trbBuyer_Scroll;
            // 
            // trbSeller
            // 
            trbSeller.BackColor = SystemColors.Control;
            trbSeller.Location = new Point(273, 252);
            trbSeller.Maximum = 12;
            trbSeller.Minimum = 1;
            trbSeller.Name = "trbSeller";
            trbSeller.Orientation = Orientation.Vertical;
            trbSeller.RightToLeft = RightToLeft.No;
            trbSeller.Size = new Size(45, 186);
            trbSeller.TabIndex = 1;
            trbSeller.TickFrequency = 0;
            trbSeller.TickStyle = TickStyle.Both;
            trbSeller.Value = 1;
            trbSeller.Scroll += trbSeller_Scroll;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(12, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(150, 225);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(215, 12);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(150, 225);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 3;
            pictureBox2.TabStop = false;
            // 
            // lblBuyersNum
            // 
            lblBuyersNum.AutoSize = true;
            lblBuyersNum.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point);
            lblBuyersNum.Location = new Point(71, 441);
            lblBuyersNum.Name = "lblBuyersNum";
            lblBuyersNum.Size = new Size(0, 25);
            lblBuyersNum.TabIndex = 4;
            // 
            // lblSellersNum
            // 
            lblSellersNum.AutoSize = true;
            lblSellersNum.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point);
            lblSellersNum.Location = new Point(273, 441);
            lblSellersNum.Name = "lblSellersNum";
            lblSellersNum.Size = new Size(0, 25);
            lblSellersNum.TabIndex = 5;
            // 
            // trbMoneySellers
            // 
            trbMoneySellers.BackColor = SystemColors.Control;
            trbMoneySellers.Location = new Point(654, 252);
            trbMoneySellers.Maximum = 30;
            trbMoneySellers.Minimum = 1;
            trbMoneySellers.Name = "trbMoneySellers";
            trbMoneySellers.Orientation = Orientation.Vertical;
            trbMoneySellers.RightToLeft = RightToLeft.No;
            trbMoneySellers.Size = new Size(45, 186);
            trbMoneySellers.TabIndex = 7;
            trbMoneySellers.TickFrequency = 0;
            trbMoneySellers.TickStyle = TickStyle.Both;
            trbMoneySellers.Value = 1;
            trbMoneySellers.Scroll += trbMoneySellers_Scroll;
            // 
            // trbMoneyBuyers
            // 
            trbMoneyBuyers.BackColor = SystemColors.Control;
            trbMoneyBuyers.Location = new Point(452, 252);
            trbMoneyBuyers.Maximum = 30;
            trbMoneyBuyers.Minimum = 1;
            trbMoneyBuyers.Name = "trbMoneyBuyers";
            trbMoneyBuyers.Orientation = Orientation.Vertical;
            trbMoneyBuyers.RightToLeft = RightToLeft.No;
            trbMoneyBuyers.Size = new Size(45, 186);
            trbMoneyBuyers.TabIndex = 6;
            trbMoneyBuyers.TickFrequency = 0;
            trbMoneyBuyers.TickStyle = TickStyle.Both;
            trbMoneyBuyers.Value = 1;
            trbMoneyBuyers.Scroll += trbMoneyBuyers_Scroll;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 40F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.FromArgb(71, 134, 168);
            label1.Location = new Point(376, 12);
            label1.Name = "label1";
            label1.Size = new Size(210, 216);
            label1.TabIndex = 8;
            label1.Text = "Money \r\nfor \r\nbuyers";
            // 
            // lblMoneySellers
            // 
            lblMoneySellers.AutoSize = true;
            lblMoneySellers.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point);
            lblMoneySellers.Location = new Point(654, 441);
            lblMoneySellers.Name = "lblMoneySellers";
            lblMoneySellers.Size = new Size(0, 25);
            lblMoneySellers.TabIndex = 10;
            // 
            // lblMoneyBuyers
            // 
            lblMoneyBuyers.AutoSize = true;
            lblMoneyBuyers.Font = new Font("Segoe UI", 13F, FontStyle.Regular, GraphicsUnit.Point);
            lblMoneyBuyers.Location = new Point(452, 441);
            lblMoneyBuyers.Name = "lblMoneyBuyers";
            lblMoneyBuyers.Size = new Size(0, 25);
            lblMoneyBuyers.TabIndex = 9;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 40F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = Color.FromArgb(241, 142, 6);
            label4.Location = new Point(578, 12);
            label4.Name = "label4";
            label4.Size = new Size(210, 216);
            label4.TabIndex = 11;
            label4.Text = "Money \r\nfor \r\nsellers";
            // 
            // btnDone
            // 
            btnDone.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point);
            btnDone.Location = new Point(775, 193);
            btnDone.Name = "btnDone";
            btnDone.Size = new Size(75, 75);
            btnDone.TabIndex = 12;
            btnDone.Text = "->";
            btnDone.UseVisualStyleBackColor = true;
            btnDone.Click += btnDone_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(862, 503);
            Controls.Add(btnDone);
            Controls.Add(label4);
            Controls.Add(lblMoneySellers);
            Controls.Add(lblMoneyBuyers);
            Controls.Add(label1);
            Controls.Add(trbMoneySellers);
            Controls.Add(trbMoneyBuyers);
            Controls.Add(lblSellersNum);
            Controls.Add(lblBuyersNum);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(trbSeller);
            Controls.Add(trbBuyer);
            Name = "Form1";
            Text = "GUI for simulation";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)trbBuyer).EndInit();
            ((System.ComponentModel.ISupportInitialize)trbSeller).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)trbMoneySellers).EndInit();
            ((System.ComponentModel.ISupportInitialize)trbMoneyBuyers).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TrackBar trbBuyer;
        private TrackBar trbSeller;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private Label lblBuyersNum;
        private Label lblSellersNum;
        private TrackBar trbMoneySellers;
        private TrackBar trbMoneyBuyers;
        private Label label1;
        private Label lblMoneySellers;
        private Label lblMoneyBuyers;
        private Label label4;
        private Button btnDone;
    }
}