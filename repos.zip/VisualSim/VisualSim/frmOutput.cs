﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace VisualSim
{
    public partial class frmOutput : Form
    {
        public frmOutput()
        {
            InitializeComponent();
        }

        private void frmOutput_Load(object sender, EventArgs e)
        {
            var dataList = LoadDataFromFile();

            GenerateControls(dataList);
        }

        private List<String> LoadDataFromFile()
        {
            // Implement your file reading logic here
            // Return a list of data objects
            var fileName = "C:\\Users\\hp\\source\\repos\\Sim suply and demand\\Sim suply and demand\\market.txt";
            var data = new List<String>();

            var lines = File.ReadLines(fileName);
            foreach (var line in lines)
            {
                data.Add(line);
            }
            return data; // Placeholder
        }

        private void GenerateControls(List<String> dataList)
        {
            int x = 10; // Starting X position
            int y = 10; // Starting Y position
            int spacing = 10; // Spacing between controls
            string blob;

            foreach (var data in dataList)
            {
                if (data.Contains("Buyer"))
                {
                    blob = "blue blob.png";
                }
                else
                {
                    blob = "orange blob.png";
                }
                // Create PictureBox
                PictureBox pictureBox = new PictureBox
                {
                    Location = new Point(x, y),
                    Size = new Size(100, 150),
                    Image = Image.FromFile($"C:\\Users\\hp\\source\\repos\\VisualSim\\VisualSim\\pics\\{blob}"),
                    SizeMode = PictureBoxSizeMode.StretchImage,
                };
                this.Controls.Add(pictureBox);

                string[] words = data.Split(' ');

                // Create Label
                Label label = new Label
                {
                    Location = new Point(x + pictureBox.Width + spacing, y + pictureBox.Height / 2),
                    Size = new Size(100, 50),
                    Text = "Amount of money: " + words[2]
                };
                this.Controls.Add(label);

                // Update Y position for next control
                y += pictureBox.Height + label.Height + spacing;
            }
        }
    }
}
